# GitHub 上传清单：xumedlab/DRnet

目标仓库：`https://github.com/xumedlab/DRnet`

建议上传的是“可复现分析代码 + 处理后结果 + 稿件相关补充材料”，不要上传 GEO 原始数据或受控访问 raw reads。GEO 数据应通过 accession 和脚本重新获取或核对。

## 必须上传

- `analysis_scripts/`
  - 全部 `.py` 分析脚本。
  - 全部 `.gmt` 基因集文件。
  - `metadata.py`、`pipeline_utils.py`、`run_all.py`。
- `analysis_data/results_tables/`
  - 全部 `.csv` 结果表，包括 differential expression、candidate selection、LASSO、GSEA、immune ssGSEA、external comparison、robustness、label permutation 和 external dataset screening 结果。
- `supplementary_tables/`
  - `Supplementary_Table_S1_macular_discovery_manifest.csv` 至 `Supplementary_Table_S14_label_permutation_check.csv`。
- `Scientific_Reports_supplementary_tables.xlsx`
  - 作为审稿人快速查看 Supplementary Tables S1-S14 的合并工作簿。
- `computational_environment.md`
  - 记录本稿件对应的软件版本。
- `Scientific_Reports_reproducibility_files.zip`
  - 作为投稿版本的冻结快照。GitHub 仓库可以展开上传各目录，同时保留该 zip 便于和投稿系统中的 Supplementary Code archive 对应。

## 建议上传

- `figures/main/`
  - 5 张主图 PDF，便于审稿人和读者核对图件。
- `figures/supplementary/`
  - 6 张补充图 PDF。
- `latex/`
  - `scientific_reports_submission.tex`
  - `scientific_reports_supplementary_material.tex`
  - `scientific_reports_references.bib`
  - `sn-jnl.cls` 及相关 LaTeX 源文件
  - `figures/` 子目录中的编译用图件
- `Scientific_Reports_LaTeX_Source.zip`
  - 投稿版本 LaTeX 源文件冻结包。
- `Scientific_Reports_cover_letter.md`
  - 只在需要公开投稿材料时上传；如果不希望公开 cover letter，可不上传。
- `README_submission_package.md`
  - 可改名为仓库根目录 `README.md`，并保留主要复现说明。
- `Scientific_Reports_requirements_vs_current_manuscript.md`
  - 可作为投稿前内部核对说明，是否公开由作者决定。

## 不建议上传

- GEO raw reads、SRA FASTQ、受控访问原始数据。
- 含个人账户路径、临时缓存、编译中间文件或日志的文件。
- 旧版本或 `former_version` 目录中的历史稿件，除非明确需要公开版本历史。

## 推荐仓库结构

```text
DRnet/
  README.md
  computational_environment.md
  analysis_scripts/
  analysis_data/
    results_tables/
  supplementary_tables/
  figures/
    main/
    supplementary/
  manuscript/
    scientific_reports_submission.tex
    scientific_reports_supplementary_material.tex
    scientific_reports_references.bib
  Scientific_Reports_supplementary_tables.xlsx
  Scientific_Reports_reproducibility_files.zip
```

## README 中应写清楚

- 本研究是 public transcriptomic reanalysis / computational candidate prioritization，不是 clinical diagnostic model。
- 主发现数据集：GSE160306。
- 支持性跨组织比较：GSE102485。
- 其他 screened public datasets 及排除原因见 Supplementary Table S6。
- 如何运行：优先说明 `analysis_scripts/run_all.py`，并补充当前稿件对应的环境版本。
- 输出位置：`analysis_data/results_tables/`、`supplementary_tables/`、`figures/`。
